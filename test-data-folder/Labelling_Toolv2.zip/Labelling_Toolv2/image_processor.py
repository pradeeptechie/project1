"""
Image Processing Module
Handles image grid overlay, cell labeling, and image preparation for annotation
"""

from PIL import Image, ImageDraw, ImageFont
import os
import io
import base64


class ImageProcessor:
    """Process images by adding grid overlay and cell labels"""
    
    def __init__(self, grid_size=8):
        """
        Initialize the image processor
        
        Args:
            grid_size (int): Number of rows/columns in the grid (default: 8)
        """
        self.grid_size = grid_size
        self.total_cells = grid_size * grid_size
    
    def create_grid_overlay(self, image_path):
        """
        Create a grid overlay on the image with cell labels
        
        Args:
            image_path (str): Path to the input image
            
        Returns:
            PIL.Image: Image with grid overlay and labels
        """
        # Open the image
        img = Image.open(image_path)
        img = img.convert('RGB')
        
        # Create a copy to draw on
        img_with_grid = img.copy()
        draw = ImageDraw.Draw(img_with_grid)
        
        # Get image dimensions
        width, height = img.size
        
        # Calculate cell dimensions
        cell_width = width / self.grid_size
        cell_height = height / self.grid_size
        
        # Draw vertical lines
        for i in range(self.grid_size + 1):
            x = int(i * cell_width)
            draw.line([(x, 0), (x, height)], fill='red', width=2)
        
        # Draw horizontal lines
        for i in range(self.grid_size + 1):
            y = int(i * cell_height)
            draw.line([(0, y), (width, y)], fill='red', width=2)
        
        # Add cell labels (1 to 64)
        try:
            # Try to use a larger font
            font_size = int(min(cell_width, cell_height) / 4)
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            # Fallback to default font
            font = ImageFont.load_default()
        
        cell_number = 1
        for row in range(self.grid_size):
            for col in range(self.grid_size):
                # Calculate cell center
                x_center = int((col + 0.5) * cell_width)
                y_center = int((row + 0.5) * cell_height)
                
                # Draw cell number
                text = str(cell_number)
                
                # Get text bounding box for centering
                bbox = draw.textbbox((0, 0), text, font=font)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                
                # Position text at top-left of cell
                text_x = int(col * cell_width + 5)
                text_y = int(row * cell_height + 5)
                
                # Draw text with background for visibility
                draw.rectangle(
                    [text_x - 2, text_y - 2, text_x + text_width + 2, text_y + text_height + 2],
                    fill='white'
                )
                draw.text((text_x, text_y), text, fill='black', font=font)
                
                cell_number += 1
        
        return img_with_grid
    
    def image_to_base64(self, img):
        """
        Convert PIL Image to base64 string for web display
        
        Args:
            img (PIL.Image): Image to convert
            
        Returns:
            str: Base64 encoded image string
        """
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        return f"data:image/png;base64,{img_str}"
    
    def get_cell_info(self, cell_number):
        """
        Get row and column information for a cell number
        
        Args:
            cell_number (int): Cell number (1 to 64)
            
        Returns:
            tuple: (row_number, column_number) both 1-indexed
        """
        # Convert to 0-indexed
        cell_index = cell_number - 1
        row = (cell_index // self.grid_size) + 1
        col = (cell_index % self.grid_size) + 1
        return row, col
