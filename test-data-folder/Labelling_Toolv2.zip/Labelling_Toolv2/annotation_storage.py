"""
Annotation Storage Module
Handles saving and loading annotations to/from CSV file
"""

import pandas as pd
import os


class AnnotationStorage:
    """Manage annotation data storage in CSV format"""
    
    def __init__(self, csv_path='annotations.csv', grid_size=8):
        """
        Initialize the annotation storage
        
        Args:
            csv_path (str): Path to the CSV file
            grid_size (int): Number of rows/columns in the grid
        """
        self.csv_path = csv_path
        self.grid_size = grid_size
        self.total_cells = grid_size * grid_size
        
        # Create CSV file with headers if it doesn't exist
        if not os.path.exists(csv_path):
            df = pd.DataFrame(columns=[
                'image_name', 
                'cell_number', 
                'row_number', 
                'column_number', 
                'label'
            ])
            df.to_csv(csv_path, index=False)
    
    def save_annotations(self, image_name, annotations):
        """
        Save annotations for an image to CSV
        
        Args:
            image_name (str): Name of the image file
            annotations (dict): Dictionary mapping cell_number to label
                               {cell_number: label}
        """
        # Read existing data
        df = pd.read_csv(self.csv_path)
        
        # Remove existing annotations for this image (if any)
        df = df[df['image_name'] != image_name]
        
        # Create new annotation rows
        new_rows = []
        for cell_number in range(1, self.total_cells + 1):
            # Get label (default to 0 if not specified)
            label = annotations.get(cell_number, 0)
            
            # Calculate row and column (1-indexed)
            row_number = ((cell_number - 1) // self.grid_size) + 1
            column_number = ((cell_number - 1) % self.grid_size) + 1
            
            new_rows.append({
                'image_name': image_name,
                'cell_number': cell_number,
                'row_number': row_number,
                'column_number': column_number,
                'label': label
            })
        
        # Append new rows
        new_df = pd.DataFrame(new_rows)
        df = pd.concat([df, new_df], ignore_index=True)
        
        # Save to CSV
        df.to_csv(self.csv_path, index=False)
    
    def get_annotations(self, image_name):
        """
        Get existing annotations for an image
        
        Args:
            image_name (str): Name of the image file
            
        Returns:
            dict: Dictionary mapping cell_number to label
        """
        if not os.path.exists(self.csv_path):
            return {}
        
        df = pd.read_csv(self.csv_path)
        image_annotations = df[df['image_name'] == image_name]
        
        if image_annotations.empty:
            return {}
        
        # Convert to dictionary
        annotations = {}
        for _, row in image_annotations.iterrows():
            annotations[int(row['cell_number'])] = int(row['label'])
        
        return annotations
    
    def is_image_annotated(self, image_name):
        """
        Check if an image has been annotated
        
        Args:
            image_name (str): Name of the image file
            
        Returns:
            bool: True if image has annotations
        """
        annotations = self.get_annotations(image_name)
        return len(annotations) > 0
