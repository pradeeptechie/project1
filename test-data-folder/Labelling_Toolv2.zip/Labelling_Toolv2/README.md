# Cricket Image Annotation Tool

[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![Flask](https://img.shields.io/badge/flask-3.0.0-green.svg)](https://flask.palletsprojects.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A powerful web-based tool for annotating cricket images with an 8x8 grid system. Features click-to-select cells and keyboard shortcuts for fast, efficient labeling of balls, bats, and stumps.

![Tool Interface](https://img.shields.io/badge/Interface-Web%20Based-brightgreen)

## ✨ Features

- 🎯 **Click-to-Select**: Click any grid cell and press hotkeys (1, 2, 3, 0) to label
- 📊 **8x8 Grid Overlay**: Automatic grid division with 64 labeled cells
- 🎨 **Visual Feedback**: Color-coded overlays for different object types
- ⌨️ **Keyboard Shortcuts**: Fast annotation with number keys
- 💾 **CSV Export**: Structured data with cell positions and labels
- 🔄 **Sequential Processing**: Navigate through multiple images easily
- 📈 **Real-time Counts**: Track labeled cells by type

## 🚀 Quick Start

### Installation

1. **Download** this tool folder
2. **Install dependencies**:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. **Add images** to the `Proc_DataSet` folder
4. **Run the app**:
   ```bash
   python app.py
   ```
5. **Open browser** at `http://localhost:5000`

For detailed installation instructions, see [INSTALL.md](INSTALL.md)

## 🎮 Usage

### Annotation Workflow

1. **Click** a cell on the image
2. **Press** a hotkey:
   - `1` → Ball (⚾)
   - `2` → Bat (🏏)
   - `3` → Stumps (🎯)
   - `0` → Remove label
3. **Save** and move to next image

### Visual Indicators

| Indicator | Meaning |
|-----------|---------|
| Blue border | Selected cell |
| Yellow overlay | Ball (label 1) |
| Blue overlay | Bat (label 2) |
| Green overlay | Stumps (label 3) |

## 📊 Output Format

Annotations are saved to `annotations.csv`:

```csv
image_name,cell_number,row_number,column_number,label
cricket_001.jpg,15,2,7,1
cricket_001.jpg,23,3,7,2
cricket_001.jpg,38,5,6,3
```

**Columns:**
- `image_name`: Image filename
- `cell_number`: Cell ID (1-64)
- `row_number`: Row position (1-8)
- `column_number`: Column position (1-8)
- `label`: 0=none, 1=ball, 2=bat, 3=stumps

## 📁 Project Structure

```
cricket-annotation-tool/
├── app.py                 # Flask web server
├── image_processor.py     # Grid overlay generation
├── annotation_storage.py  # CSV data management
├── requirements.txt       # Dependencies
├── INSTALL.md            # Installation guide
├── README.md             # This file
├── templates/            # HTML templates
│   ├── annotate.html    # Main interface
│   ├── no_images.html   # Error page
│   └── complete.html    # Completion page
├── Proc_DataSet/        # Image folder (add your images here)
└── annotations.csv      # Output file (auto-generated)
```

## 🔧 Requirements

- Python 3.7+
- Flask 3.0.0
- Pillow 10.1.0
- NumPy 1.24.3
- Pandas 2.1.3

## 🎨 Screenshots

The tool provides:
- Interactive grid overlay on images
- Real-time cell selection with visual feedback
- Label count tracking
- Progress bar showing completion status

## ⚙️ Configuration

### Change Image Folder

Edit `app.py` line 14:
```python
DATASET_FOLDER = r'path\to\your\images'
```

### Change Grid Size

Edit `app.py` line 15:
```python
GRID_SIZE = 10  # For 10x10 grid
```

### Change Port

Edit `app.py` line 152:
```python
app.run(debug=True, host='localhost', port=5001)
```

## 🐛 Troubleshooting

**No images found?**
- Ensure images are in `Proc_DataSet` folder
- Check file extensions: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.gif`, `.webp`

**Module not found?**
```bash
python -m pip install Flask Pillow numpy pandas
```

**Port already in use?**
- Change port in `app.py` (see Configuration above)

## 📝 License

This project is licensed under the MIT License - feel free to use, modify, and distribute.

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest features
- Submit pull requests

## 💡 Use Cases

- Cricket analytics and training
- Object detection dataset creation
- Sports image annotation
- Machine learning data preparation

## 🎯 Roadmap

- [ ] Support for custom label types
- [ ] Batch export to multiple formats
- [ ] Undo/redo functionality
- [ ] Image zoom and pan
- [ ] Annotation statistics dashboard

---

**Made with ❤️ for cricket analytics**

For detailed setup instructions, see [INSTALL.md](INSTALL.md)
