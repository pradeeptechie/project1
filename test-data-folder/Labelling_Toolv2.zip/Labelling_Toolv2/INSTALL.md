# Cricket Image Annotation Tool - Installation Guide

## 📦 Quick Start

This tool allows you to annotate cricket images with a grid-based labeling system using an interactive web interface.

## 🔧 Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

## 📥 Installation Steps

### 1. Download the Tool

**Option A: Download as ZIP**
- Download the entire `cricket-annotation-tool` folder
- Extract to your desired location

**Option B: Clone with Git** (if available)
```bash
git clone <repository-url>
cd cricket-annotation-tool
```

### 2. Install Dependencies

Open a terminal/command prompt in the tool directory and run:

```bash
python -m pip install -r requirements.txt
```

This will install:
- Flask (web framework)
- Pillow (image processing)
- NumPy (numerical operations)
- Pandas (CSV data handling)

### 3. Prepare Your Images

1. Place your cricket images in the `Proc_DataSet` folder
2. Supported formats: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.gif`, `.webp`

**Note:** If you want to use a different folder, edit `app.py` line 14:
```python
DATASET_FOLDER = r'path\to\your\images'
```

### 4. Run the Application

```bash
python app.py
```

You should see:
```
============================================================
Image Annotation Tool
============================================================
Dataset folder: Proc_DataSet
Annotations will be saved to: annotations.csv
Grid size: 8x8

Starting server...
Open your browser and go to: http://localhost:5000
============================================================
```

### 5. Open in Browser

Navigate to: **http://localhost:5000**

## 🎯 How to Use

### Click-to-Select Mode (Recommended)

1. **Click** on any cell in the image grid
2. **Press a hotkey** to assign a label:
   - `1` = Ball (yellow overlay)
   - `2` = Bat (blue overlay)
   - `3` = Stumps (green overlay)
   - `0` = Remove label
3. **Repeat** for other cells
4. **Click "Save & Next Image"** when done

### Visual Feedback

- **Blue border**: Currently selected cell
- **Yellow overlay** (⚾): Ball
- **Blue overlay** (🏏): Bat
- **Green overlay** (🎯): Stumps
- **Label counts**: Real-time count displayed in cards

### Navigation

- **Save & Next Image**: Save annotations and move to next
- **Clear All**: Remove all annotations for current image
- **Skip Image**: Move to next without saving

## 📊 Output

Annotations are saved to `annotations.csv` with this structure:

| Column | Description |
|--------|-------------|
| `image_name` | Image filename |
| `cell_number` | Cell number (1-64) |
| `row_number` | Row in grid (1-8) |
| `column_number` | Column in grid (1-8) |
| `label` | 0=none, 1=ball, 2=bat, 3=stumps |

## 🛠️ Troubleshooting

### "No module named 'flask'" error
```bash
python -m pip install Flask Pillow numpy pandas
```

### "No images found" message
- Check that images are in the correct folder
- Verify image file extensions are supported
- Ensure folder path in `app.py` is correct

### Port already in use
Edit `app.py` line 152 to change the port:
```python
app.run(debug=True, host='localhost', port=5001)  # Changed to 5001
```

### CSV file empty or corrupted
Delete `annotations.csv` and restart the application. It will create a new file with proper headers.

## 📁 Project Structure

```
cricket-annotation-tool/
├── app.py                    # Main Flask application
├── image_processor.py        # Image grid overlay utilities
├── annotation_storage.py     # CSV storage management
├── requirements.txt          # Python dependencies
├── INSTALL.md               # This file
├── README.md                # Detailed documentation
├── templates/               # HTML templates
│   ├── annotate.html       # Main annotation interface
│   ├── no_images.html      # Error page
│   └── complete.html       # Completion page
├── Proc_DataSet/           # Your images go here
└── annotations.csv         # Generated annotations

```

## 🚀 Advanced Configuration

### Change Grid Size

Edit `app.py` line 15:
```python
GRID_SIZE = 10  # Change from 8 to 10 for 10x10 grid
```

### Add More Label Types

Edit `templates/annotate.html` to add additional label buttons and hotkeys.

### Custom CSV Location

Edit `app.py` line 19:
```python
annotation_storage = AnnotationStorage(csv_path='my_annotations.csv', grid_size=GRID_SIZE)
```

## 💡 Tips

- Use keyboard shortcuts for faster annotation
- The grid overlay helps identify exact cell positions
- All annotations are saved incrementally (won't lose work)
- You can re-annotate images by running them through again

## 📞 Support

For issues or questions:
1. Check the troubleshooting section above
2. Verify all dependencies are installed
3. Ensure Python version is 3.7 or higher

---

**Ready to start annotating!** 🏏
