"""
Flask Web Application for Image Annotation
Provides interactive interface for annotating images with grid cells
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
from image_processor import ImageProcessor
from annotation_storage import AnnotationStorage

app = Flask(__name__)

# Configuration
DATASET_FOLDER = r'D:\P_ML\Project\Proc_DataSet'
GRID_SIZE = 8

# Initialize components
image_processor = ImageProcessor(grid_size=GRID_SIZE)
annotation_storage = AnnotationStorage(csv_path='annotations.csv', grid_size=GRID_SIZE)

# Global state
current_image_index = 0
image_files = []


def get_image_files():
    """Get list of image files from the dataset folder"""
    if not os.path.exists(DATASET_FOLDER):
        os.makedirs(DATASET_FOLDER)
        return []
    
    valid_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp'}
    files = []
    
    for filename in os.listdir(DATASET_FOLDER):
        ext = os.path.splitext(filename)[1].lower()
        if ext in valid_extensions:
            files.append(filename)
    
    return sorted(files)


@app.route('/')
def index():
    """Main page - redirect to annotation interface"""
    global image_files, current_image_index
    
    # Load image files
    image_files = get_image_files()
    
    if not image_files:
        return render_template('no_images.html', folder=DATASET_FOLDER)
    
    # Reset to first image
    current_image_index = 0
    
    return redirect(url_for('annotate'))


@app.route('/annotate')
def annotate():
    """Annotation interface page"""
    global current_image_index, image_files
    
    if not image_files:
        return redirect(url_for('index'))
    
    if current_image_index >= len(image_files):
        return render_template('complete.html', total_images=len(image_files))
    
    # Get current image
    image_name = image_files[current_image_index]
    image_path = os.path.join(DATASET_FOLDER, image_name)
    
    # Create grid overlay
    img_with_grid = image_processor.create_grid_overlay(image_path)
    img_base64 = image_processor.image_to_base64(img_with_grid)
    
    # Get existing annotations (if any)
    existing_annotations = annotation_storage.get_annotations(image_name)
    
    return render_template(
        'annotate.html',
        image_name=image_name,
        image_data=img_base64,
        current_index=current_image_index + 1,
        total_images=len(image_files),
        grid_size=GRID_SIZE,
        existing_annotations=existing_annotations
    )


@app.route('/save_annotations', methods=['POST'])
def save_annotations():
    """Save annotations for current image and move to next"""
    global current_image_index, image_files
    
    data = request.json
    image_name = data.get('image_name')
    annotations = data.get('annotations', {})
    
    # Convert string keys to integers
    annotations = {int(k): int(v) for k, v in annotations.items()}
    
    # Save to CSV
    annotation_storage.save_annotations(image_name, annotations)
    
    # Move to next image
    current_image_index += 1
    
    return jsonify({
        'success': True,
        'next_image': current_image_index < len(image_files)
    })


@app.route('/skip_image', methods=['POST'])
def skip_image():
    """Skip current image without saving"""
    global current_image_index, image_files
    
    current_image_index += 1
    
    return jsonify({
        'success': True,
        'next_image': current_image_index < len(image_files)
    })


@app.route('/previous_image', methods=['POST'])
def previous_image():
    """Go back to previous image"""
    global current_image_index
    
    if current_image_index > 0:
        current_image_index -= 1
    
    return jsonify({'success': True})


if __name__ == '__main__':
    print("=" * 60)
    print("Image Annotation Tool")
    print("=" * 60)
    print(f"Dataset folder: {DATASET_FOLDER}")
    print(f"Annotations will be saved to: annotations.csv")
    print(f"Grid size: {GRID_SIZE}x{GRID_SIZE}")
    print("\nStarting server...")
    print("Open your browser and go to: http://localhost:5000")
    print("=" * 60)
    
    app.run(debug=True, host='localhost', port=5000)
