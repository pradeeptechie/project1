import os
import cv2

#RAW_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/output-jpeg"
#OUT_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"

RAW_DIR = r"D:/iit-bombay-learning/semester1/project1/shared-image-download/bat, ball, stumps"
OUT_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/bat, ball, stumps_images_800x600"


os.makedirs(OUT_DIR, exist_ok=True)

TARGET_W, TARGET_H = 800, 600

def is_valid_size(img):
    h, w = img.shape[:2]
    return (w >= TARGET_W) and (h >= TARGET_H)

for fname in os.listdir(RAW_DIR):
    if not fname.lower().endswith((".jpg", ".jpeg", ".png")):
        continue

    in_path = os.path.join(RAW_DIR, fname)
    img = cv2.imread(in_path)

    if img is None:
        print("Could not read:", fname)
        continue

    if not is_valid_size(img):
        print("Skipping (too small):", fname)
        continue

    # Resize to 800x600
    resized = cv2.resize(img, (TARGET_W, TARGET_H), interpolation=cv2.INTER_AREA)
    out_path = os.path.join(OUT_DIR, fname)
    cv2.imwrite(out_path, resized)
    print("Saved resized:", out_path)
