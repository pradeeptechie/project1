import os
import csv
import cv2
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

# CONFIG
IMAGE_FOLDER = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
OUTPUT_CSV = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/leveling/annotations_labeled.csv"

GRID_ROWS = 8
GRID_COLS = 8
IMG_W, IMG_H = 800, 600
CELL_W, CELL_H = IMG_W // GRID_COLS, IMG_H // GRID_ROWS

current_image_index = 0
image_list = [f for f in os.listdir(IMAGE_FOLDER) if f.lower().endswith((".jpeg", ".jpg", ".png"))]
image_list.sort()

# To store labels for current image (64 cells)
labels = [0] * 64


def load_image(index):
    """Load an image and return OpenCV + Tkinter versions."""
    global cv_img, tk_img, labels

    if index < 0 or index >= len(image_list):
        messagebox.showinfo("Info", "All images annotated!")
        return None

    labels = [0] * 64  # reset labels

    img_path = os.path.join(IMAGE_FOLDER, image_list[index])
    cv_img = cv2.imread(img_path)

    if cv_img is None:
        messagebox.showerror("Error", f"Cannot read image: {img_path}")
        return None

    cv_img_rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
    pil_img = Image.fromarray(cv_img_rgb)
    tk_img = ImageTk.PhotoImage(pil_img)

    canvas.itemconfig(canvas_img, image=tk_img)
    update_title()

    return True


def update_title():
    """Update window title with file name."""
    img_name = image_list[current_image_index]
    root.title(f"Image Labeling Tool - {img_name}")


def save_current_labels():
    """Append labels to CSV."""
    img_name = image_list[current_image_index]

    file_exists = os.path.isfile(OUTPUT_CSV)

    with open(OUTPUT_CSV, "a", newline="") as f:
        writer = csv.writer(f)

        # write header if first time
        if not file_exists:
            header = ["ImageFileName"] + [f"c{i:02d}" for i in range(1, 65)]
            writer.writerow(header)

        row = [img_name] + labels
        writer.writerow(row)

    print(f"Saved: {img_name}")


def next_image():
    """Save labels & load next image."""
    global current_image_index

    save_current_labels()

    current_image_index += 1
    if current_image_index >= len(image_list):
        messagebox.showinfo("Done", "All images annotated!")
        root.quit()
        return

    load_image(current_image_index)
    draw_grid()


def click_event(event):
    """Handle cell click and assign label."""
    global labels

    col = event.x // CELL_W
    row = event.y // CELL_H

    cell_index = row * GRID_COLS + col

    label = label_var.get()
    labels[cell_index] = label

    draw_grid()  # refresh with updated colored cells


def draw_grid():
    """Draw grid + filled color for labeled cells."""
    canvas.delete("gridline")
    canvas.delete("cellcolor")

    # Color-coded view of labels
    for idx, val in enumerate(labels):
        r = idx // GRID_COLS
        c = idx % GRID_COLS

        x1 = c * CELL_W
        y1 = r * CELL_H
        x2 = x1 + CELL_W
        y2 = y1 + CELL_H

        if val == 1:  # ball
            color = "yellow"
        elif val == 2:  # bat
            color = "orange"
        elif val == 3:  # stumps
            color = "cyan"
        else:
            continue

        canvas.create_rectangle(x1, y1, x2, y2, outline="", fill=color, stipple="gray25", tags="cellcolor")

    # Draw grid
    for i in range(1, GRID_COLS):
        x = i * CELL_W
        canvas.create_line(x, 0, x, IMG_H, fill="green", tags="gridline")

    for i in range(1, GRID_ROWS):
        y = i * CELL_H
        canvas.create_line(0, y, IMG_W, y, fill="green", tags="gridline")


# ------------------- GUI SETUP --------------------

root = tk.Tk()
root.geometry("900x700")

label_var = tk.IntVar(value=0)

frame = tk.Frame(root)
frame.pack()

tk.Radiobutton(frame, text="0 = No Object", variable=label_var, value=0).pack(side=tk.LEFT)
tk.Radiobutton(frame, text="1 = Ball", variable=label_var, value=1).pack(side=tk.LEFT)
tk.Radiobutton(frame, text="2 = Bat", variable=label_var, value=2).pack(side=tk.LEFT)
tk.Radiobutton(frame, text="3 = Stumps", variable=label_var, value=3).pack(side=tk.LEFT)

button_next = tk.Button(root, text="SAVE & NEXT IMAGE", command=next_image, bg="lightblue")
button_next.pack(pady=10)

canvas = tk.Canvas(root, width=IMG_W, height=IMG_H)
canvas.pack()

canvas_img = canvas.create_image(0, 0, anchor="nw")
canvas.bind("<Button-1>", click_event)

# Load first image
load_image(0)
draw_grid()

root.mainloop()
