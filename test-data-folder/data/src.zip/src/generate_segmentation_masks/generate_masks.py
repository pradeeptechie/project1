import os
import pandas as pd
import numpy as np
from PIL import Image

#Generate Segmentation Masks (Per-Pixel Mask Images)

IMG_W, IMG_H = 800, 600
GRID = 8
CELL_W, CELL_H = IMG_W // GRID, IMG_H // GRID


IMAGE_FOLDER = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/testing_image_800_600"
CSV_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/testing_image_800_600/annotations.csv"   # change to full path if needed
MASK_OUT = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/masks_output_images"

os.makedirs(MASK_OUT, exist_ok=True)

df = pd.read_csv(CSV_PATH)
grouped = df.groupby("image_name")

for img_name, rows in grouped:
    mask = np.zeros((IMG_H, IMG_W), dtype=np.uint8)

    for _, r in rows.iterrows():
        label = int(r["label"])
        if label == 0:
            continue

        r_idx = int(r["row_number"]) - 1  # FIX
        c_idx = int(r["column_number"]) - 1  # FIX

        x1, y1 = c_idx * CELL_W, r_idx * CELL_H
        x2, y2 = x1 + CELL_W, y1 + CELL_H

        mask[y1:y2, x1:x2] = label

    # Save true mask (0-3)
    Image.fromarray(mask).save(os.path.join(MASK_OUT, f"{img_name}_mask.png"))

    # Save visible mask for debugging
    mask_vis = (mask * 80).astype("uint8")
    Image.fromarray(mask_vis).save(os.path.join(MASK_OUT, f"{img_name}_mask_visible.png"))

print("✔ Masks generated (both real + visible)!")
