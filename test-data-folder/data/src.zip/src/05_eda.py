import os
import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ANNOT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/leveling/annotations_labeled.csv"
IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"

df = pd.read_csv(ANNOT_PATH)

print("\n===== BASIC DATASET INFO =====")
print(df.head())
print(df.shape)

###########################################################
# 1. COUNT OBJECTS PER CLASS (Total)
###########################################################

all_labels = []

for col in df.columns:
    if col.startswith("c"):
        all_labels.extend(df[col].values)

all_labels = np.array(all_labels)

unique, counts = np.unique(all_labels, return_counts=True)
class_dist = dict(zip(unique, counts))

print("\n===== TOTAL OBJECT COUNT ACROSS ALL CELLS =====")
print("0 = No Object")
print("1 = Ball")
print("2 = Bat")
print("3 = Stumps")
print(class_dist)

plt.figure(figsize=(6,4))
sns.barplot(x=list(class_dist.keys()), y=list(class_dist.values()))
plt.title("Class Distribution Across All Cells")
plt.xlabel("Class")
plt.ylabel("Count")
plt.show()

###########################################################
# 2. OBJECTS PER IMAGE
###########################################################

df["Total_Objects"] = df[[c for c in df.columns if c.startswith("c")]].apply(lambda x: sum(x > 0), axis=1)

plt.figure(figsize=(8,4))
sns.histplot(df["Total_Objects"], bins=20, kde=True)
plt.title("Distribution of Object Count Per Image")
plt.xlabel("Number of Objects (per image)")
plt.ylabel("Frequency")
plt.show()

###########################################################
# 3. OBJECT HEATMAP PER GRID CELL (64 cells)
###########################################################

cell_cols = [f"c{i:02d}" for i in range(1, 65)]

heatmap_data = np.zeros((8, 8))

for idx, cell in enumerate(cell_cols):
    row = idx // 8
    col = idx % 8
    heatmap_data[row, col] = np.sum(df[cell] > 0)

plt.figure(figsize=(7,6))
sns.heatmap(heatmap_data, annot=True, fmt=".0f", cmap="YlOrRd")
plt.title("Heatmap: Object Frequency Per Grid Cell")
plt.xlabel("Columns (1–8)")
plt.ylabel("Rows (1–8)")
plt.show()

###########################################################
# 4. SEPARATE HEATMAPS FOR BALL, BAT, STUMPS
###########################################################

def create_heatmap_for_class(class_id, title):
    heat = np.zeros((8, 8))
    for idx, cell in enumerate(cell_cols):
        row = idx // 8
        col = idx % 8
        heat[row, col] = np.sum(df[cell] == class_id)

    plt.figure(figsize=(7,6))
    sns.heatmap(heat, annot=True, fmt=".0f", cmap="Blues")
    plt.title(title)
    plt.show()

create_heatmap_for_class(1, "Ball Frequency Heatmap")
create_heatmap_for_class(2, "Bat Frequency Heatmap")
create_heatmap_for_class(3, "Stumps Frequency Heatmap")

###########################################################
# 5. SAMPLE IMAGES WITH GRID OVERLAY
###########################################################

def show_image_with_grid(fname):
    img_path = os.path.join(IMG_DIR, fname)
    img = cv2.imread(img_path)

    for i in range(8):
        cv2.line(img, (i*100, 0), (i*100, 600), (0,255,0), 1)
        cv2.line(img, (0, i*75), (800, i*75), (0,255,0), 1)

    plt.figure(figsize=(8,6))
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.title(fname)
    plt.axis("off")
    plt.show()

# Show first 3 images
for i in range(3):
    show_image_with_grid(df["ImageFileName"].iloc[i])

###########################################################
# 6. COLOR ANALYSIS (Brightness distribution)
###########################################################

brightness_values = []

for fname in df["ImageFileName"]:
    path = os.path.join(IMG_DIR, fname)
    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    brightness_values.append(np.mean(gray))

plt.figure(figsize=(8,4))
sns.histplot(brightness_values, bins=20, kde=True)
plt.title("Brightness Distribution of Images")
plt.xlabel("Mean Brightness")
plt.ylabel("Count")
plt.show()

###########################################################
# 7. EDGE DENSITY ANALYSIS
###########################################################

edge_density = []

for fname in df["ImageFileName"]:
    path = os.path.join(IMG_DIR, fname)
    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    edge_density.append(np.sum(edges > 0) / edges.size)

plt.figure(figsize=(8,4))
sns.histplot(edge_density, bins=20, kde=True)
plt.title("Edge Density Distribution Across Images")
plt.xlabel("Edge Density")
plt.ylabel("Count")
plt.show()

###########################################################
# 8. CHECK ANNOTATION QUALITY
###########################################################

df["MissingLabels"] = df[cell_cols].apply(lambda x: sum(x < 0), axis=1)

plt.figure(figsize=(8,4))
sns.histplot(df["MissingLabels"], bins=20, kde=True)
plt.title("Label Missing Count Per Image")
plt.xlabel("Number of Missing Cells")
plt.ylabel("Frequency")
plt.show()

print("\n===== IMAGES WITH MISSING LABELS =====")
print(df[df["MissingLabels"] > 0][["ImageFileName", "MissingLabels"]])
