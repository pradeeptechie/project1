import os
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

# =============================
# CONFIGURATION
# =============================
#IMAGE_FOLDER = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/testing_image_800_600"
#CSV_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/testing_image_800_600/annotations.csv"   # change to full path if needed
IMAGE_FOLDER = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
CSV_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600/annotations.csv"   # change to full path if needed
OUTPUT_FOLDER = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/colour_coded_images"

IMG_WIDTH = 800
IMG_HEIGHT = 600

GRID_ROWS = 8
GRID_COLS = 8

CELL_W = IMG_WIDTH // GRID_COLS  # 100 px
CELL_H = IMG_HEIGHT // GRID_ROWS  # 75 px

COLOR_MAP = {
    1: (255, 0, 0, 120),    # Ball = red
    2: (0, 255, 0, 120),    # Bat = green
    3: (0, 0, 255, 120)     # Stumps = blue
}

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load font for cell numbers
try:
    FONT = ImageFont.truetype("arial.ttf", 20)
except:
    FONT = ImageFont.load_default()


# =============================
# MAIN FUNCTION
# =============================
def draw_grid_coloured(image_name, annotations):

    img_path = os.path.join(IMAGE_FOLDER, image_name)
    if not os.path.exists(img_path):
        print("Missing image:", image_name)
        return

    # Load image
    base_img = Image.open(img_path).convert("RGBA")
    overlay = Image.new("RGBA", base_img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    # === Draw COLOR CODING from annotation ===
    for _, row in annotations.iterrows():

        label = int(row["label"])
        if label == 0:
            continue

        # Convert row/col (1–8) → index (0–7)
        r = int(row["row_number"]) - 1
        c = int(row["column_number"]) - 1

        x1 = c * CELL_W
        y1 = r * CELL_H
        x2 = x1 + CELL_W
        y2 = y1 + CELL_H

        draw.rectangle([x1, y1, x2, y2], fill=COLOR_MAP[label])

    # === Draw GRID LINES & CELL NUMBERS ===
    draw_grid = ImageDraw.Draw(overlay)

    # Grid lines
    for r in range(GRID_ROWS + 1):
        y = r * CELL_H
        draw_grid.line([(0, y), (IMG_WIDTH, y)], fill="yellow", width=2)

    for c in range(GRID_COLS + 1):
        x = c * CELL_W
        draw_grid.line([(x, 0), (x, IMG_HEIGHT)], fill="yellow", width=2)

    # Cell numbers
    cell_no = 1
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            x = c * CELL_W + 5
            y = r * CELL_H + 5
            draw_grid.text((x, y), str(cell_no), fill="yellow", font=FONT)
            cell_no += 1

    # === Merge & Save ===
    final_img = Image.alpha_composite(base_img, overlay)
    final_img = final_img.convert("RGB")  # JPEG compatible

    out_path = os.path.join(OUTPUT_FOLDER, f"grid_coloured_{image_name}")
    final_img.save(out_path)

    print("Saved:", out_path)


# =============================
# PROCESS ALL IMAGES
# =============================
df = pd.read_csv(CSV_PATH)
grouped = df.groupby("image_name")

for image_name, group in grouped:
    draw_grid_coloured(image_name, group)

print("\n ALL DONE: Grid + Numbers + Color overlays generated!")