import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.decomposition import PCA

# ---------------------------------------------------------
# Load Feature Dataset (must be created earlier)
# ---------------------------------------------------------
X_train = np.load("X_train.npy")
y_train = np.load("y_train.npy")
X_test  = np.load("X_test.npy")
y_test  = np.load("y_test.npy")

print("Train Shape:", X_train.shape)
print("Test Shape :", X_test.shape)

# Standardize features (important for SVM & LR)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

# ---------------------------------------------------------
# Helper: Plot Confusion Matrix
# ---------------------------------------------------------
def plot_confusion(cm, title):
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.title(title)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()


# ---------------------------------------------------------
# 1. Logistic Regression
# ---------------------------------------------------------
lr = LogisticRegression(max_iter=2000, multi_class="ovr")
lr.fit(X_train_s, y_train)

pred_lr = lr.predict(X_test_s)
acc_lr = accuracy_score(y_test, pred_lr)

cm_lr = confusion_matrix(y_test, pred_lr)
plot_confusion(cm_lr, "Logistic Regression – Confusion Matrix")

print("\nLogistic Regression Accuracy:", acc_lr)


# ---------------------------------------------------------
# 2. Logistic Regression + Polynomial Features
# ---------------------------------------------------------
poly = PolynomialFeatures(degree=2, include_bias=False)
X_train_poly = poly.fit_transform(X_train_s)
X_test_poly = poly.transform(X_test_s)

lr_poly = LogisticRegression(max_iter=3000, multi_class="ovr")
lr_poly.fit(X_train_poly, y_train)

pred_lr_poly = lr_poly.predict(X_test_poly)
acc_lr_poly = accuracy_score(y_test, pred_lr_poly)

cm_lr_poly = confusion_matrix(y_test, pred_lr_poly)
plot_confusion(cm_lr_poly, "Logistic Regression + Polynomial Features")

print("\nLogistic Regression + Polynomial Features Accuracy:", acc_lr_poly)


# ---------------------------------------------------------
# 3. SVC with Linear Kernel
# ---------------------------------------------------------
svc_linear = SVC(kernel="linear")
svc_linear.fit(X_train_s, y_train)

pred_svc_linear = svc_linear.predict(X_test_s)
acc_svc_linear = accuracy_score(y_test, pred_svc_linear)

cm_svc_linear = confusion_matrix(y_test, pred_svc_linear)
plot_confusion(cm_svc_linear, "SVC (Linear Kernel) – Confusion Matrix")

print("\nSVC (Linear Kernel) Accuracy:", acc_svc_linear)


# ---------------------------------------------------------
# 4. SVC with RBF Kernel
# ---------------------------------------------------------
svc_rbf = SVC(kernel="rbf")
svc_rbf.fit(X_train_s, y_train)

pred_svc_rbf = svc_rbf.predict(X_test_s)
acc_svc_rbf = accuracy_score(y_test, pred_svc_rbf)

cm_svc_rbf = confusion_matrix(y_test, pred_svc_rbf)
plot_confusion(cm_svc_rbf, "SVC (RBF Kernel) – Confusion Matrix")

print("\nSVC (RBF Kernel) Accuracy:", acc_svc_rbf)


# ---------------------------------------------------------
# 5. Accuracy Comparison Plot
# ---------------------------------------------------------
models = ["LogReg", "Poly LogReg", "SVC Linear", "SVC RBF"]
accuracies = [acc_lr, acc_lr_poly, acc_svc_linear, acc_svc_rbf]

plt.figure(figsize=(7,4))
sns.barplot(x=models, y=accuracies)
plt.ylim(0,1)
plt.title("Model Accuracy Comparison")
plt.ylabel("Accuracy")
plt.show()


# ---------------------------------------------------------
# 6. PCA Visualization of Model Predictions
# ---------------------------------------------------------
pca = PCA(n_components=2)
X_test_pca = pca.fit_transform(X_test_s)

def plot_pca(pred, title):
    plt.figure(figsize=(6,5))
    plt.scatter(X_test_pca[:,0], X_test_pca[:,1], c=pred, cmap="viridis", s=10)
    plt.title(title)
    plt.xlabel("PCA1")
    plt.ylabel("PCA2")
    plt.colorbar()
    plt.show()

plot_pca(pred_lr, "PCA Visualization – Logistic Regression")
plot_pca(pred_lr_poly, "PCA Visualization – Poly Logistic Regression")
plot_pca(pred_svc_linear, "PCA Visualization – SVC Linear")
plot_pca(pred_svc_rbf, "PCA Visualization – SVC RBF")
