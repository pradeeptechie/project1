import os
import cv2
import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from utils import get_cell, extract_features_from_cell

IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
ANNOT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/leveling/annotations_labeled.csv"
SPLIT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/train_test_split.csv"
MODEL_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/models/model_pradeep.pkl"

os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

# 1. Read annotations and split info
df_annot = pd.read_csv(ANNOT_PATH)
df_split = pd.read_csv(SPLIT_PATH)

df = df_annot.merge(df_split, on="ImageFileName", how="inner")

# 2. Build feature matrix
X_train, y_train = [], []
X_test, y_test = [], []

for idx, row in df.iterrows():
    fname = row["ImageFileName"]
    part = row["TrainOrTest"]  # "Train" or "Test"
    img_path = os.path.join(IMG_DIR, fname)

    img = cv2.imread(img_path)
    if img is None:
        print("Could not read:", img_path)
        continue

    for cell_idx in range(1, 65):
        col_name = f"c{cell_idx:02d}"
        label = int(row[col_name])

        # If some cells are still unlabeled, skip them
        if label < 0:
            continue

        # Convert cell_idx to (row, col)
        cell_zero_based = cell_idx - 1
        r = cell_zero_based // 8
        c = cell_zero_based % 8

        cell_img = get_cell(img, r, c)
        feats = extract_features_from_cell(cell_img)

        if part == "Train":
            X_train.append(feats)
            y_train.append(label)
        else:
            X_test.append(feats)
            y_test.append(label)

X_train = np.vstack(X_train)
y_train = np.array(y_train)
X_test = np.vstack(X_test)
y_test = np.array(y_test)

print("Train samples:", X_train.shape, "Test samples:", X_test.shape)

# 3. Train model (Random Forest)
clf = RandomForestClassifier(
    n_estimators=200,
    max_depth=None,
    random_state=42,
    n_jobs=-1
)

clf.fit(X_train, y_train)

# 4. Evaluate
y_pred_train = clf.predict(X_train)
y_pred_test = clf.predict(X_test)

print("=== Train Classification Report ===")
print(classification_report(y_train, y_pred_train))

print("=== Test Classification Report ===")
print(classification_report(y_test, y_pred_test))

# 5. Save model
joblib.dump(clf, MODEL_PATH)
print("Saved model to:", MODEL_PATH)
