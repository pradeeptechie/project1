from PIL import Image
import os

def convert_folder_webp_to_jpeg(input_dir, output_dir, quality=90):
    """
    Converts all .webp images in the input directory to .jpeg format
    and saves them in the output directory.

    Args:
        input_dir (str): Path to the folder containing the .webp images.
        output_dir (str): Path to the folder where .jpeg images will be saved.
        quality (int): JPEG compression quality (0-100). Higher is better quality.
    """
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created output directory: {output_dir}")

    # Count of files processed
    converted_count = 0
    
    # Loop through every item (file or folder) in the input directory
    for filename in os.listdir(input_dir):
        # 1. Check if the file has the .webp extension (case-insensitive)
        if filename.lower().endswith('.webp'):
            
            # 2. Define the full paths
            input_path = os.path.join(input_dir, filename)
            
            # Create the output filename by replacing .webp with .jpeg
            name_only = os.path.splitext(filename)[0]
            output_filename = name_only + ".jpeg"
            output_path = os.path.join(output_dir, output_filename)
            
            try:
                # 3. Open the image
                img = Image.open(input_path)
                
                # 4. Save the image in JPEG format
                # The 'jpeg' argument specifies the encoder to use.
                img.save(output_path, "jpeg", quality=quality)
                
                print(f"Converted: {filename} -> {output_filename}")
                converted_count += 1
                
            except Exception as e:
                print(f"Error converting {filename}: {e}")

    print(f"\n--- Conversion Complete: {converted_count} files processed. ---")


# --- Configuration ---
# Define the source and destination folders
SOURCE_FOLDER = r"D:\iit-bombay-learning\semester1\project1\pradeep-own-project\project_cricket_detection\data\raw-webp"  # UPDATE THIS PATH
OUTPUT_FOLDER = r"D:\iit-bombay-learning\semester1\project1\pradeep-own-project\project_cricket_detection\data\output-jpeg" # UPDATE THIS PATH

# Run the conversion function
convert_folder_webp_to_jpeg(SOURCE_FOLDER, OUTPUT_FOLDER, quality=95)