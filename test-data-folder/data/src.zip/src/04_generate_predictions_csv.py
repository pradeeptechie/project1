import os
import cv2
import joblib
import numpy as np
import pandas as pd

from utils import get_cell, extract_features_from_cell

IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
SPLIT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/train_test_split.csv"
MODEL_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/models/model_pradeep.pkl"
OUT_CSV = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/outputs/predictions_all.csv"

os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)

# Load model
clf = joblib.load(MODEL_PATH)

# Load split info
df_split = pd.read_csv(SPLIT_PATH)

rows = []
for idx, row in df_split.iterrows():
    fname = row["ImageFileName"]
    part = row["TrainOrTest"]

    img_path = os.path.join(IMG_DIR, fname)
    img = cv2.imread(img_path)
    if img is None:
        print("Could not read:", img_path)
        continue

    cell_preds = []
    for cell_idx in range(1, 65):
        zero_based = cell_idx - 1
        r = zero_based // 8
        c = zero_based % 8

        cell_img = get_cell(img, r, c)
        feats = extract_features_from_cell(cell_img)
        pred = clf.predict(feats.reshape(1, -1))[0]
        cell_preds.append(int(pred))

    out_row = {
        "ImageFileName": fname,
        "TrainOrTest": part
    }
    for cell_idx in range(1, 65):
        out_row[f"c{cell_idx:02d}"] = cell_preds[cell_idx - 1]

    rows.append(out_row)

df_out = pd.DataFrame(rows)
df_out.to_csv(OUT_CSV, index=False)
print("Saved predictions to:", OUT_CSV)
