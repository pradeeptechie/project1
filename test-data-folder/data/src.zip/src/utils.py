import cv2
import numpy as np
from skimage.feature import hog

CELL_W, CELL_H = 100, 75  # 800/8, 600/8

def get_cell(img, row, col):
    """
    img: HxWxC BGR image (OpenCV)
    row, col: 0..7
    """
    y1 = row * CELL_H
    y2 = (row + 1) * CELL_H
    x1 = col * CELL_W
    x2 = (col + 1) * CELL_W
    return img[y1:y2, x1:x2, :]

def extract_features_from_cell(cell_bgr):
    # Convert to HSV
    cell_hsv = cv2.cvtColor(cell_bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(cell_hsv)

    feats = []

    # 1. Mean & Std of H, S, V
    for ch in (h, s, v):
        feats.append(np.mean(ch))
        feats.append(np.std(ch))

    # 2. Histograms
    # H: 0-180 in OpenCV
    h_hist = cv2.calcHist([h], [0], None, [16], [0, 180]).flatten()
    s_hist = cv2.calcHist([s], [0], None, [8], [0, 256]).flatten()
    v_hist = cv2.calcHist([v], [0], None, [8], [0, 256]).flatten()

    # Normalize histograms
    h_hist = h_hist / (np.sum(h_hist) + 1e-6)
    s_hist = s_hist / (np.sum(s_hist) + 1e-6)
    v_hist = v_hist / (np.sum(v_hist) + 1e-6)

    feats.extend(h_hist)
    feats.extend(s_hist)
    feats.extend(v_hist)

    # 3. Edge density (Canny)
    gray = cv2.cvtColor(cell_bgr, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, threshold1=100, threshold2=200)
    edge_density = np.sum(edges > 0) / edges.size
    feats.append(edge_density)

    # 4. HOG features
    # Resize cell for HOG stability
    cell_gray_resized = cv2.resize(gray, (64, 64))
    hog_feats = hog(cell_gray_resized,
                    orientations=9,
                    pixels_per_cell=(8, 8),
                    cells_per_block=(2, 2),
                    block_norm="L2-Hys",
                    feature_vector=True)
    feats.extend(hog_feats.tolist())

    return np.array(feats, dtype=np.float32)
