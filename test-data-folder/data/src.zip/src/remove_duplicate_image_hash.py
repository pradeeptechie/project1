import os
import hashlib

def file_hash(path, block_size=65536):
    hasher = hashlib.md5()
    with open(path, 'rb') as f:
        buf = f.read(block_size)
        while buf:
            hasher.update(buf)
            buf = f.read(block_size)
    return hasher.hexdigest()

def remove_duplicate_images(folder_path):
    hashes = {}
    removed_files = []

    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff', '.webp')):
                file_path = os.path.join(root, file)
                file_hash_value = file_hash(file_path)

                if file_hash_value in hashes:
                    print(f"Duplicate found → Removing: {file_path}")
                    os.remove(file_path)
                    removed_files.append(file_path)
                else:
                    hashes[file_hash_value] = file_path

    print("\nTotal duplicates removed:", len(removed_files))
    return removed_files

# -------- RUN ----------
folder = r"D:\iit-bombay-learning\semester1\project1\pradeep-own-project\project_cricket_detection\data\bat, ball, stumps_images_800x600-after-remove-duplicate"   # 🔥 Change this
remove_duplicate_images(folder)
