import pandas as pd

# ==========================
# INPUT / OUTPUT PATHS
# ==========================
INPUT_CSV = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600/annotations.csv"
OUTPUT_CSV = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600/annotations_template.csv"

# ==========================
# READ INPUT CSV
# ==========================
df = pd.read_csv(INPUT_CSV)

# ==========================
# PREPARE OUTPUT STRUCTURE
# ==========================
output_rows = []

# Column names: ImageFileName, c01 ... c64
columns = ["ImageFileName"] + [f"c{i:02d}" for i in range(1, 65)]

# ==========================
# PROCESS EACH IMAGE
# ==========================
for image_name, group in df.groupby("image_name"):

    # Initialize all 64 cells with 0 (no object)
    cell_values = [0] * 64

    for _, row in group.iterrows():
        cell_num = int(row["cell_number"])   # 1 to 64
        label = int(row["label"])             # 0,1,2,3

        # Place label in correct index
        cell_values[cell_num - 1] = label

    # Create final row
    output_row = [image_name] + cell_values
    output_rows.append(output_row)

# ==========================
# WRITE OUTPUT CSV
# ==========================
output_df = pd.DataFrame(output_rows, columns=columns)
output_df.to_csv(OUTPUT_CSV, index=False)

print(f" Transposed annotation file saved as: {OUTPUT_CSV}")
