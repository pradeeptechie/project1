import os
import random
import pandas as pd

IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
SPLIT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/train_test_split.csv"

random.seed(42)

image_files = sorted([
    f for f in os.listdir(IMG_DIR)
    if f.lower().endswith((".jpg", ".jpeg", ".png"))
])

random.shuffle(image_files)

n = len(image_files)
train_count = int(0.7 * n)  # 70% train, 30% test

split_rows = []
for i, fname in enumerate(image_files):
    part = "Train" if i < train_count else "Test"
    split_rows.append({"ImageFileName": fname, "TrainOrTest": part})

df_split = pd.DataFrame(split_rows)
df_split.to_csv(SPLIT_PATH, index=False)
print("Saved split info:", SPLIT_PATH)
