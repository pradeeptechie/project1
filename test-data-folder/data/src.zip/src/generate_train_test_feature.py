import os
import cv2
import numpy as np
import pandas as pd
from skimage.feature import hog

# --------------------------------------------------------
# CONFIG PATHS
# --------------------------------------------------------
IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
ANNOT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/leveling/annotations_labeled.csv"
SPLIT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/train_test_split.csv"


# --------------------------------------------------------
# GRID SIZE
# --------------------------------------------------------
CELL_W = 100  # 800 / 8
CELL_H = 75   # 600 / 8

def crop_cell(img, r, c):
    y1 = r * CELL_H
    y2 = (r + 1) * CELL_H
    x1 = c * CELL_W
    x2 = (c + 1) * CELL_W
    return img[y1:y2, x1:x2]


# --------------------------------------------------------
# FEATURE EXTRACTION FUNCTION
# --------------------------------------------------------
def extract_features(cell):

    # Convert to gray
    gray = cv2.cvtColor(cell, cv2.COLOR_BGR2GRAY)
    
    # 1. Edge density
    edges = cv2.Canny(gray, 100, 200)
    edge_density = np.sum(edges > 0) / edges.size
    
    # 2. HOG 
    cell_resized = cv2.resize(gray, (64, 64))
    hog_feats = hog(cell_resized,
                    orientations=9,
                    pixels_per_cell=(8, 8),
                    cells_per_block=(2, 2),
                    block_norm="L2-Hys",
                    feature_vector=True)
    
    # 3. Color means
    hsv = cv2.cvtColor(cell, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)

    features = [
        np.mean(h), np.mean(s), np.mean(v),
        np.std(h), np.std(s), np.std(v),
        edge_density
    ]

    features.extend(hog_feats.tolist())
    return np.array(features, dtype=np.float32)


# --------------------------------------------------------
# LOAD ANNOTATIONS & SPLIT
# --------------------------------------------------------
df_annot = pd.read_csv(ANNOT_PATH)
df_split = pd.read_csv(SPLIT_PATH)

df = df_annot.merge(df_split, on="ImageFileName")

# --------------------------------------------------------
# STORAGE
# --------------------------------------------------------
X_train, y_train = [], []
X_test, y_test = [], []

# --------------------------------------------------------
# PROCESS EACH IMAGE
# --------------------------------------------------------
for idx, row in df.iterrows():
    
    fname = row["ImageFileName"]
    part  = row["TrainOrTest"]
    
    img_path = os.path.join(IMG_DIR, fname)
    img = cv2.imread(img_path)

    if img is None:
        print("Error loading:", fname)
        continue

    for cell_idx in range(1, 65):
        label = int(row[f"c{cell_idx:02d}"])

        # -1 means not labeled → skip
        if label < 0:
            continue

        r = (cell_idx - 1) // 8
        c = (cell_idx - 1) % 8

        cell = crop_cell(img, r, c)
        feats = extract_features(cell)

        if part == "Train":
            X_train.append(feats)
            y_train.append(label)
        else:
            X_test.append(feats)
            y_test.append(label)

# --------------------------------------------------------
# SAVE AS NUMPY FILES
# --------------------------------------------------------
X_train = np.array(X_train)
y_train = np.array(y_train)
X_test  = np.array(X_test)
y_test  = np.array(y_test)

np.save("X_train.npy", X_train)
np.save("y_train.npy", y_train)
np.save("X_test.npy",  X_test)
np.save("y_test.npy",  y_test)

print("\nSaved:")
print("X_train.npy:", X_train.shape)
print("y_train.npy:", y_train.shape)
print("X_test.npy :", X_test.shape)
print("y_test.npy :", y_test.shape)
