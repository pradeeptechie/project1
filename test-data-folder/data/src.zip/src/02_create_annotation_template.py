import os
import pandas as pd

IMG_DIR = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/images_800x600"
ANNOT_PATH = r"D:/iit-bombay-learning/semester1/project1/pradeep-own-project/project_cricket_detection/data/annotations/annotations_template.csv"

os.makedirs(os.path.dirname(ANNOT_PATH), exist_ok=True)

# List all images
image_files = sorted([
    f for f in os.listdir(IMG_DIR)
    if f.lower().endswith((".jpg", ".jpeg", ".png"))
])

cols = ["ImageFileName"] + [f"c{i:02d}" for i in range(1, 65)]

rows = []
for fname in image_files:
    row = {"ImageFileName": fname}
    for i in range(1, 65):
        row[f"c{i:02d}"] = -1   # -1 = not labeled yet
    rows.append(row)

df = pd.DataFrame(rows, columns=cols)
df.to_csv(ANNOT_PATH, index=False)
print("Template created at:", ANNOT_PATH)
